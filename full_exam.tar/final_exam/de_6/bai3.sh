#Tạo thư mục /KMA
mkdir /KMA;
#Tạo file svktmm.txt trong /KMA
echo "Một ngày tốt lành" > /KMA/svktmm.txt
#Thay đổi nội dung file
echo "Dương Thế Duy" >> /KMA/svktmm.txt
#Xem lại nội dung file sau khi thay đổi
cat /KMA/svktmm.txt
cd /
#Nén file
tar cvf /home/kma...gz2 KMA/*
