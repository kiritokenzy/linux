#Kiểm tra cấu hình
echo "Thông tin CPU: " 
lscpu
echo "Thông tin RAM: "
cat /proc/meminfo | grep -i mem
echo "Thông tin ổ đĩa: "
lsblk -f
#Kiểm tra địa chỉ IP và subnetmask của máy tính
echo "Địa chỉ IP: " $(ifconfig | grep -i inet);
echo "Subnet mask: " $(ifconfig | grep -i netmask)
#Đổi địa chỉ IP
ifconfig ens33 190.0.0.1 netmask 255.255.0.0
systemctl restart NetworkManager
#Kiểm tra mtu
ifconfig | grep mtu;
ifconfig ens33 mtu 2000
#Nén file
tar cvf /KMA.tar KMA/*
