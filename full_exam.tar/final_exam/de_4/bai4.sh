#Tạo cây thư mục /KMA/Baitap
mkdir -p /KMA/Baitap
#Trong /KMA/Baitap tạo file vanban2.txt 
echo "This is contet of vanban2.txt" > /KMA/Baitap/vanban2.txt
#Xem thuộc tính của tập tin vanban2.txt
ls -l /KMA/Baitap
#Gán lại quyền với số hiệu 744. Xem lại quyền đã thay đổi
chmod 744 /KMA/Baitap/vanban2.txt
#Tạo người dùng U25
useradd -m U25;
echo "U25:abc@123" | chpasswd;
#Để U25 có thể sửa được file vanban.txt ta cần cấp quyền write và execute cho other với folder /KMA/Baitap
chmod o+wx /KMA/Baitap
ls -l /KMA
#Đăng nhập với U25, đổi tên vanban2.txt thành soanthao.txt
su U25 -c "mv /KMA/Baitap/vanban2.txt /KMA/Baitap/soanthao.txt";
tree /KMA
#Kiểm tra địa chỉ mạng, địa chỉ quảng bá của máy
ifconfig -a
