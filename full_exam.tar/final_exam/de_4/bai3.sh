#Tạo người dùng U1 với mật khẩu abc@123
useradd -m U1;
echo "U1:abc@123" | chpasswd;
#Tạo file F1.txt trong thư mục chủ U1 và xem sự tồn tại
echo "This is F1.txt content" > /home/U1/F1.txt
tree /home/U1
#Tạo file f1.txt trong thư mục chủ U1 và xem sự tồn tại
echo "This is f1.txt content" > /home/U1/f1.txt
tree /home/U1
#Xem thuộc tính của tập tin F1.txt và f1.txt
ls -l /home/U1
echo "Giải thích: Việc 2 thư mục F1.txt và f1.txt có thể cùng tồn tại trong cùng một thư mục chủ U1 vì trong Linux phân biệt ký tự hoa (uppercase) và ký tự thường (lowercase)." 
