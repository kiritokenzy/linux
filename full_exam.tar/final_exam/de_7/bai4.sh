#Tạo tài khoản user123 và user456
PASSWORD="123"
useradd -m user123;
useradd -m user456;
echo "user123:$PASSWORD" | chpasswd
echo "user456:$PASSWORD" | chpasswd
#Đăng nhập tài khoản user123
su user123 -c "mkdir /home/user123/baitap && echo Dương Thế Duy - CT070213 > /home/user123/baitap/test.txt";
chmod 766 /home/user123/baitap/test.txt;
#user123 kiểm tra xem thư mục /baitap có quyền gì
su user123 -c "ls -ld /home/user123/baitap"
#Nén thư mục baitap thành baitap.gz
tar cvf /home/user123/baitap.gz /home/user123/baitap/*
#Đổi tên tài khoản user456 thành 789user
usermod -l 789user user456
