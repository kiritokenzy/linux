#Tạo người dùng user1
useradd -m user1
echo "user1:sv123456" | chpasswd
#Tạo group 1
groupadd group1
#Gán người dùng user1 vào nhóm group1 
usermod -aG group1 user1
#Xem số hiệu user1 và group 1
cat /etc/passwd | grep -i user1;
cat /etc/group | grep -i group1
#Xem đường dẫn thư mục chủ của user1
echo "Đường dẫn user1: " $(su user1 -c "cd ~ && pwd" )
#Tạo file1.txt trong thư mục chủ user1
echo "This is content o1 file1.txt" > /home/user1/file1.txt
#Xem nội dung file1.txt
echo "Nội dung: " $(cat /home/user1/file1.txt)
#Xem thuộc tính tập tin file1.txt
ls -l /home/user1/file1.txt | grep -i file1.txt
#Giải thích

