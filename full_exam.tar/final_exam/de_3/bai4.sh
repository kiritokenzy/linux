#Đặt IP tĩnh trên máy chủ Linux
ifconfig ens37 192.168.0.100 netmask 255.255.255.0
ifconfig ens37
systemctl restart NetworkManager
#Kiểm tra địa chỉ mạng trên máy cục bộ
echo "Localhost IP: "
hostname -I
#Ping thông tới máy vật lí có địa chỉ ip là 192.168.0.101
ping -c 8 192.168.56.1
#Thay đổi địa chỉ ip mới
ifconfig ens37 192.168.1.200 netmask 255.255.255.252
#Kiểm tra lại ip sau khi thay đổi
ifconfig ens37
#Tải một file từ trang download.net/file1
wget download.net/file1
