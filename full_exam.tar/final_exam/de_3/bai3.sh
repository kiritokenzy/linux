#Xem danh sách ổ đĩa có trên Linux
echo "Danh sách ổ đĩa: "
lsblk
#Tạo thư mục /KMA/Security và /THI
mkdir -p /KMA/Security;
mkdir -p /THI;
#Ánh xạ ổ đĩa cdrom sr0 vào thư mục /KMA/Security
mount /dev/sr0 /KMA/Security
#Copy một file bất kì trong /KMA/Security tới ổ đĩa gốc /THI
cp -r /KMA/Security/md5sum.txt /THI
tree /THI
