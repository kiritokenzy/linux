#Xem danh sách ổ đĩa có trên Linux
lsblk -f
#Tạo thư mục KMA/data
mkdir -p /KMA/data
#Thực hiện ánh xạ ổ đĩa cdrom vào thư mục /KMA/data
mount /dev/sr0 /KMA/data
#Sao chép một file bất kì trong /KMA/data tới thư mục gốc
cp -r /KMA/data/md5sum.txt /
#Kiểm tra xem trong thư mục gốc đã có file vừa sao chép hay chưa
ls -l /
