#Xem danh mục các tiến trình đang thực hiện
ps -aux
#Dừng một tiến trình đang thực hiện, ví dụ là vim
kill -STOP $(pgrep -f vim)
echo STOP A PROCESS
ps aux | tail -6
#Thay đổi độ ưu tiên của tiến trình
renice 10 -p $(pgrep -f vim)
echo CHANGE PRIORITY
ps aux | tail -6
#Xóa một tiến trình, ví dụ là vim
kill -9 $(pgrep -f vim)
echo KILL A PROCESS
ps aux | tail -6
#Kiểm tra tài nguyên RAM của hệ thống Linux
free -h
#Kiểm tra tài nguyên vể ổ đĩa trên Linux
lsblk -f
#Tạo một file test.txt và kiểm tra quyền của file đó, ghi thông tin vào file và nén file đó với tên bất kỳ
echo > test1.txt
ls -ld test1.txt
echo "This is content of test.txt" >> test1.txt
tar cvf test1.gz test1.txt
ls -l
