#Tạo tài khoản User123 mật khẩu 2711, tạo nhóm G123
useradd -m User123;
echo "User123:2711" | chpasswd
groupadd G123;
usermod -aG G123 User123
#Tạo file /KMA/test2.txt
mkdir /KMA
echo "This is content of test2.txt" > /KMA/test2.txt
chgrp G123 /KMA
chmod 755 /KMA
su User123 -c "cd /KMA && tar cvf /home/User123/filenen.gz test2.txt"
ls /home/User123
ps -a 
