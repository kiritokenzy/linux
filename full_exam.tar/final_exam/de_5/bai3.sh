#Tạo người dùng user1 với mật khẩu tùy ý
useradd -m user1;
echo "user1:sv123456" | chpasswd;
#Tạo nhóm group1
:
usermod -aG group1 user1;
#Kiểm tra thông tin user1
id user1;
#Xem đường dẫn thư mục chủ user1;
echo "Đường dẫn của thư mục chủ user1: " $(su user1 -c "cd ~ && pwd")
#Tạo tập tin file1.txt trong thư mục chủ user1
echo "This is content of file1.txt..." > /home/user1/file1.txt
echo "file1.txt's content: " $(cat /home/user1/file1.txt)
#Xem thuộc tính tập tin file1.txt
ls -l /home/user1
