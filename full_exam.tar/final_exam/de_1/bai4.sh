#Định dạng ổ đĩa với định dạng ext4 với mục tiêu là phân cùng sdb1
mkfs -t ext4 /dev/sdb1
echo "Kết quả: " 
lsblk -f /dev/sdb
#Tạo thư mục /THI_HK và /THI2_HK nếu chưa tồn tại
mkdir -p /THI1_HK;
mkdir -p /THI2_HK;
echo "Tạo thư mục thành công!"
#Gắn ổ đĩa với thư mục /THI1_HK
mount /dev/sdb1 /THI1_HK
echo "Kết quả: "
lsblk -f /dev/sdb
echo "Mount thành công"
#Sao lưu một file bất kì từ ổ đĩa vào /THI2_HK bằng câu lệnh rsync
echo abc > /home/U1/text2.txt
rsync -azvh /home/U1/text2.txt /THI2_HK
#Copy một file bất kì vào thư mục /THI1_HK
echo xyz > /home/U1/text1.txt
cp /home/U1/text1.txt /THI1_HK
#Hủy bỏ gắn kết giữa THI1_HK
umount /THI1_HK
#Kiểm tra sự tồn tại file vừa copy vào thư mục /THI1_HK
if [ -f /THI1_HK/text1.txt ]; then
        echo "Tồn tại file"
else
        echo "Không tồn tại file vì đã umount, không thể kiểm tra trong thư mục /THI1_HK"
fi
#Cơ chế ánh xạ ổ đĩa mount/umount:
#Mount: Kết nối một hệ thống file trên một thiết bị lưu trữ vào cây thư mục hệ thống, được truy cập thông qua mount point (thường là một thư mục)
#Umount: Ngược lại với mount
#Khi thiết bị được kết nối, cần phải thực hiện việc mount thiết bị với mount point
