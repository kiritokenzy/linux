#Tạo user U1 và U2 với cùng mật khẩu sv123456
PASSWORD="sv123456"
useradd -m U1;
useradd -m U2;
echo "U1:$PASSWORD" | chpasswd;
echo "U2:$PASSWORD" | chpasswd;
#Xem thông tin về người dùng
echo "Thông tin U1: " $(id U1);
echo "Thông tin U2: " $(id U2);
#Xem đường dẫn hiện tại với U1
echo "Đường dẫn hiện tại với U1: " $(su U1 -c "cd ~ && pwd");
#Tạo thư mục KMA_U1 trong thư mục U1
mkdir /home/U1/KMA_U1;
#Di chuyển thư mục KMA_U1 sang thư mục chủ U2
mv /home/U1/KMA_U1 /home/U2/
#Kiểm tra xem thư mục KMA_U1 đã sang U2 hay chưa
cd /home/U2
ls -l
if [ -d /home/U2/KMA_U1 ]; then
       echo "Đã di chuyển";
else
 	echo "Chưa di chuyển";
fi	
