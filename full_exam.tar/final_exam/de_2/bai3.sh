#Tạo người dùng U3, U4 và thiết lập mật khẩu tương ứng là
useradd -m U3;
useradd -m U4;
echo "U3:u3_123" | chpasswd;
echo "U4:u4_456" | chpasswd;
#Gán người dùng vào nhóm root
usermod -aG root U3;
usermod -aG root U4;
#Tạo thư mục KMA2 trong thư mục gốc
mkdir /KMA2;
#Sao chép thư mục KMA2 vào thư mục chủ U3
cp -r /KMA2 /home/U3/
tree /home/U3
#Đăng nhập với tài khoản U3, thực hiện xóa /KMA2
su U3 -c "rm -rf /home/U3/KMA2"
tree /home/U3

