#Kiểm tra cấu hình máy tính
echo "Thông tin CPU: "; 
lshw -C cpu | grep -i product
echo "Thông tin RAM: ";
free
echo "Thông tin bộ nhớ: ";
lsblk
#Định dang ổ đĩa với định dạng ext2
mkfs -t ext2 /dev/sdc1
#Tạo thư mục /THI/THUCHANH
mkdir -p /THI/THUCHANH
#Gắn ổ đĩa với thư mục /THI/THUCHANH
mount /dev/sdc1 /THI/THUCHANH
lsblk /dev/sdc1
#Sao chép một file bất kì trong thư mục gốc vào thư mục /THI/THUCHANH
echo abc > /a.txt
cp -r /a.txt /THI/THUCHANH
tree /THI/THUCHANH
#Hủy bỏ gắn kết giữa thư mục THI/THUCHANH với ổ đĩa
umount /THI/THUCHANH
lsblk -f /dev/sdc1
